@echo off
chcp 65001 >nul
echo ====================================
echo   中医易学助手 APK一键构建工具
echo ====================================
echo.

echo [1/4] 检查Flutter环境...
where flutter >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 错误：未找到Flutter，请先安装Flutter SDK
    echo 下载地址：https://flutter.dev/docs/get-started/install
    pause
    exit /b 1
)
echo ✅ Flutter已安装
flutter --version
echo.

echo [2/4] 获取项目依赖...
call flutter pub get
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 获取依赖失败
    pause
    exit /b 1
)
echo ✅ 依赖获取成功
echo.

echo [3/4] 构建正式版APK...
call flutter build apk --release
if %ERRORLEVEL% NEQ 0 (
    echo ❌ APK构建失败
    pause
    exit /b 1
)
echo ✅ APK构建成功
echo.

echo [4/4] 完成！
echo.
echo ====================================
echo   APK文件位置：
echo   build\app\outputs\flutter-apk\app-release.apk
echo ====================================
echo.
echo 您可以直接将该APK文件安装到Android手机使用
echo.
pause
